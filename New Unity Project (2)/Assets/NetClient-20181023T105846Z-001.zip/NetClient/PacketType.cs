public enum PacketType : byte {
  Failure = 0,
  LobbyInfo = 1,
  Login = 6,
}